package com.dineout.code.reporting;


public class order
{
    public order()
    {
        loss = 0;
        total_amount = 0;
    }

    //loss of particular order
    public int loss;

    //total_amount paid for a particular order
    public int total_amount;

}
